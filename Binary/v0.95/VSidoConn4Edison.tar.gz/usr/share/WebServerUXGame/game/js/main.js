	$(function(){
		//var s_edison_ip='192.168.11.2';	// �����삷�郍�{�b�g���w��E�Œ肵�����ꍇ��ip���`
		
		var s_edison_ip_enemy='192.168.11.2';	// �f�t�H���g
		var qparam=getUrlVars()['enemyip'];
		if(qparam){
			s_edison_ip_enemy=qparam;
		}

		// ��`�֘A
		var UI_CONST={
			MOVE_GRID_HALF:60,
			MOVE_GRID:120,
			
			TOP_PADDING_ALIGN:5,
			RIGHT_PADDING_ALIGN:5,
			BAR_HEIGHT:10,
			BAR_SPACER:4,
			
			TEXT_HEIGHT_OFFSET:9,
			
			WIN: 1,
			LOSE: -1,

			WIN_MSG:"YOU WIN!!!",
			LOSE_MSG:"YOU LOSE!!!",
			RESET_MSG:"",
			
			WIN_IMG: "./libs/res/result-win.png",
			LOSE_IMG: "./libs/res/result-lose.png",
			
			SHIELD_WIDTH: 472,
			POWER_WIDTH: 472,
		};
		var GAME_CONST={
			MIN_ATTACKABLE_DISTANCE:4,
			
			MAX_DEVICE_ROT:60,
			MINUS_CAMERA_ORI:300,
			CAMERA_ROT_DELIMITER:Math.sin(59*Math.PI/180),
			MAX_CAMERA_ROT:60,
			
			MAX_SHIELD:150,
			MAX_POWER:150,
			
			ATK_POWER:20,
			MIN_ATTACK_DAMAGE:10,
			
			TARGET_WIN_HEIGHT:120,			
			TARGET_WIN_WIDTH:160,
			
			MOVE_UP: 1,
			MOVE_RIGHT: 2,
			MOVE_DOWN: 3,
			MOVE_LEFT: 4,
		};
		var ROBOT_MODE={
			UNACTIVE:0,
			ACTIVE:1,
		};
		var PROCESS_FLAGS={
			NONE:0,
			MOTION:1 << 0,
			CAMERA:1 << 1,
			IK:1 << 2,
		};
		var CMD_TYPE={
			NONE:0,
			ATTACK:1,
			WIN:2,
			RESPAWN:3,
		};
		var SHOW_EFFECT={
			NONE:0,
			KNOCKOUT:1,
			DAMAGE:2,
			ATTACK:3,
		};
		var SHOW_EFFECT_FRAME={
			DAMAGE:15,
			ATTACK:3,
		};
		var APP_TIMER={
			RENDER_LOOP:33,		// �`�惋�[�v [ms]
			CONTROL_LOOP:33,	// ���䃋�[�v [ms]
		};
		var TIMER_TYPE={
			RENDERER:0,
			CONTROL:1,
		};
		
		var CUSTOM_MOTION={
			'lowerhands':{'inuse':false,'playframe':0,'motion':[{'kid':2,'dat':[
			[0,0,-100]]
			},{'kid':3,'dat':[
			[0,0,-100]]
			}]},
			'crouch':{'inuse':false,'playframe':0,'motion':[{'kid':4,'dat':[
			[0,0,-90],[0,0,-89],[0,0,-88],[0,0,-87],[0,0,-86],[0,0,-85],[0,0,-84],[0,0,-83],[0,0,-82],[0,0,-81],[0,0,-80],[0,0,-79],[0,0,-78],[0,0,-77],[0,0,-76],[0,0,-75],[0,0,-74],[0,0,-73],[0,0,-72],[0,0,-71],[0,0,-70],[0,0,-69],[0,0,-68],[0,0,-67],[0,0,-66],[0,0,-65],[0,0,-64],[0,0,-63],[0,0,-62],[0,0,-61],[0,0,-60]]
			},{'kid':5,'dat':[
			[0,0,-90],[0,0,-89],[0,0,-88],[0,0,-87],[0,0,-86],[0,0,-85],[0,0,-84],[0,0,-83],[0,0,-82],[0,0,-81],[0,0,-80],[0,0,-79],[0,0,-78],[0,0,-77],[0,0,-76],[0,0,-75],[0,0,-74],[0,0,-73],[0,0,-72],[0,0,-71],[0,0,-70],[0,0,-69],[0,0,-68],[0,0,-67],[0,0,-66],[0,0,-65],[0,0,-64],[0,0,-63],[0,0,-62],[0,0,-61],[0,0,-60]]
			}]},
			'standup':{'inuse':false,'playframe':0,'motion':[{'kid':4,'dat':[
			[0,0,-60],[0,0,-61],[0,0,-62],[0,0,-63],[0,0,-64],[0,0,-65],[0,0,-66],[0,0,-67],[0,0,-68],[0,0,-69],[0,0,-70],[0,0,-71],[0,0,-72],[0,0,-73],[0,0,-74],[0,0,-75],[0,0,-76],[0,0,-77],[0,0,-78],[0,0,-79],[0,0,-80],[0,0,-81],[0,0,-82],[0,0,-83],[0,0,-84],[0,0,-85],[0,0,-86],[0,0,-87],[0,0,-88],[0,0,-89],[0,0,-90]]
			},{'kid':5,'dat':[
			[0,0,-60],[0,0,-61],[0,0,-62],[0,0,-63],[0,0,-64],[0,0,-65],[0,0,-66],[0,0,-67],[0,0,-68],[0,0,-69],[0,0,-70],[0,0,-71],[0,0,-72],[0,0,-73],[0,0,-74],[0,0,-75],[0,0,-76],[0,0,-77],[0,0,-78],[0,0,-79],[0,0,-80],[0,0,-81],[0,0,-82],[0,0,-83],[0,0,-84],[0,0,-85],[0,0,-86],[0,0,-87],[0,0,-88],[0,0,-89],[0,0,-90]]
			}]},
			'attack':{'inuse':false,'playframe':0,'motion':[{'kid':2,'dat':[
			[0,0,-100],[0,-25,-75],[0,-50,-50],[0,-75,-25],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100]]
			},{'kid':3,'dat':[
			[0,0,-100],[0,-25,-75],[0,-50,-50],[0,-75,-25],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,-100,0],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100],[0,0,-100]]
			}]},
			'win':{'inuse':false,'playframe':0,'motion':[{'kid':0,'dat':[]}]},
			'lose':{'inuse':false,'playframe':0,'motion':[{'kid':0,'dat':[]}]},
		};

		// -----------------------------------------------------
		var s_effect_data={
			damage:0,
			attack:0,
		};
		var s_timer=[null,null];
		
		var s_mask_image=[
			['',0], // NONE
			['url(./libs/res/damage.gif)',10000,3000], // KNOCKOUT
		];
		
		// �Q�[���֘A
		var s_game_data={
			mypoints:0,
			enemypoints:0,
			marker_x:0,
			marker_y:0,
		};
		
		// ���{�b�g�֘A�ϐ�
		var s_robot={
			camera:0,
			forward:0,
			side:0,
			flags:0,
			lastprocess:PROCESS_FLAGS.MOTION,
			power:GAME_CONST.MAX_POWER,
			shield:GAME_CONST.MAX_SHIELD,
			mode:ROBOT_MODE.ACTIVE,
		};

		// �`��֘A�ϐ�
		var s_canvas={
			instance:$('#game-canvas')[0],
			context:$('#game-canvas')[0].getContext('2d'),
		};
		
		// V-SidoWeb�֘A
		//var s_vsido=new VSidoWeb({'ip':s_edison_ip});	// �����삷�郍�{�b�g���w��E�Œ肵�����ꍇ��ip��ݒ�
		var s_vsido=new VSidoWeb();
		
		var s_camera=null,s_r2r=null;
		var s_vsido_data={
			walk:s_vsido.walk(),
			angle:s_vsido.servoAngle(),
			ik:s_vsido.ik(),
		};
		s_vsido_data.angle["cycle"]=10;
		s_vsido_data.angle['servo'].push({'sid':2,'angle':0});
		
		s_vsido_data.ik['ikf']['dist']['pos']=true;
		
		// �t���O����֘A
		function offflag(bit){s_robot.flags&=~bit};
		function setflag(bit){s_robot.flags|=bit;}
		function isflagup(bit){return (s_robot.flags&bit);}
		function resetflag(){s_robot.flags=PROCESS_FLAGS.NONE;}
		
		// --------------------------------------------------------
		// Marker
		function updatetarget(x,y,direct){
			if(direct){
				s_game_data.marker_x=x;
				s_game_data.marker_y=y;
			}else{
				s_game_data.marker_x=0;
				s_game_data.marker_y=0;			
			}
		}
		
		// SYYSTEM Message
		function systemmessage(msg){$('#systemmsg').text(msg);}
		
		// ���[�V�����֘A
		function playmotion(motion){
			if('attack'==motion){
				if(!CUSTOM_MOTION['attack']['inuse']){
					CUSTOM_MOTION['attack']['playframe']=0;
					CUSTOM_MOTION['attack']['inuse']=true;
				}
			}else if('lowerhands'==motion){
				if(!CUSTOM_MOTION['lowerhands']['inuse']){
					CUSTOM_MOTION['lowerhands']['playframe']=0;
					CUSTOM_MOTION['lowerhands']['inuse']=true;
				}				
			}else if('crouch'==motion){
				if(!CUSTOM_MOTION['crouch']['inuse']){
					CUSTOM_MOTION['crouch']['playframe']=0;
					CUSTOM_MOTION['crouch']['inuse']=true;
				}
			}else if('standup'==motion){
				if(!CUSTOM_MOTION['standup']['inuse']){
					CUSTOM_MOTION['standup']['playframe']=0;
					CUSTOM_MOTION['standup']['inuse']=true;
				}
			}
			setflag(PROCESS_FLAGS.IK);
		}
		
		// �G�t�F�N�g�֘A
		function showeffect(show){
			var maskobj=$('#mask');
			if(show==SHOW_EFFECT.KNOCKOUT){
				maskobj.css("background-image",s_mask_image[show][0]);
				maskobj.show().delay(s_mask_image[show][1]).fadeOut(s_mask_image[show][2],respawn);
			}else if(show==SHOW_EFFECT.DAMAGE){
				s_effect_data.damage=1;
			}else if(show==SHOW_EFFECT.ATTACK){
				s_effect_data.attack=1;
			}
		}

		// �f�[�^���[�v
		function dataupdate(){
			if(++s_robot.power>GAME_CONST.MAX_POWER)s_robot.power=GAME_CONST.MAX_POWER;
		}

		// �`�惋�[�v
		function canvasloop(){
			var context=s_canvas.context;
			context.clearRect(0,0,s_canvas.instance.width,s_canvas.instance.height);
			
			var right=s_canvas.instance.width;
			var rightalign=UI_CONST.RIGHT_PADDING_ALIGN;
			var bottom=s_canvas.instance.height;
			var center_x=right/2;
			var center_y=s_canvas.instance.height/2;
				
			context.globalAlpha=1.0;				
			if(s_effect_data.attack){	
				context.beginPath();
				var radius=20/s_effect_data.attack;
				var frame_ratio=1-s_effect_data.attack/SHOW_EFFECT_FRAME.ATTACK;
				var marker_x=s_game_data.marker_x;
				var marker_y=s_game_data.marker_y;
				var x_offset=((center_x/2)*frame_ratio);
				var ratio_x=center_x+x_offset;
				var ratio_y=center_y+(center_y*frame_ratio);
				PRINT(ratio_x+" - "+ratio_y+" : "+marker_x+" - "+marker_y);
				context.arc(ratio_x,ratio_y,radius,2*Math.PI,false);
				context.arc(center_x-x_offset,ratio_y,radius,2*Math.PI,false);
				context.fillStyle='yellow';
				context.lineWidth=10;
//				context.fill();
				
				if(s_effect_data.attack++>=SHOW_EFFECT_FRAME.ATTACK)s_effect_data.attack=0;
			}
			
			if(s_effect_data.damage){			
				context.globalAlpha=1-(s_effect_data.damage/SHOW_EFFECT_FRAME.DAMAGE);
				context.beginPath();
				context.rect(0,0,right,bottom);
				context.fillStyle='red';
				context.fill();
				if(s_effect_data.damage++>=SHOW_EFFECT_FRAME.DAMAGE)s_effect_data.damage=0;
			}

			context.globalAlpha=1.0;
			// SHIELD
//			context.fillStyle="#33CC00";
//			context.fillRect(right-(s_robot.shield+rightalign), UI_CONST.TOP_PADDING_ALIGN, s_robot.shield, UI_CONST.BAR_HEIGHT);

			// POWER
			var spacer=UI_CONST.TOP_PADDING_ALIGN+UI_CONST.BAR_HEIGHT+UI_CONST.BAR_SPACER;
//			context.fillStyle="#3333FF";
//			context.fillRect(right-(s_robot.power+rightalign), spacer, s_robot.power, UI_CONST.BAR_HEIGHT);

			drawGauge( 'shield', s_robot.shield);
			drawGauge( 'power', s_robot.power);

			// TARGET
			s_game_data.marker_x
			s_game_data.marker_y
			context.fillStyle="#FF0000";
			context.font='30pt Calibri';
			context.textAlign='left';
//			context.fillText('TARGET',s_game_data.marker_x,s_game_data.marker_y);
			
			// TEXT
			var text_right_align=right-rightalign*2;
			context.fillStyle="#FFFFFF";
			context.font='10pt Calibri';
			context.textAlign='right';
//			context.fillText('SHIELD',text_right_align,UI_CONST.TOP_PADDING_ALIGN+UI_CONST.TEXT_HEIGHT_OFFSET);
//			context.fillText('POWER',text_right_align,spacer+UI_CONST.TEXT_HEIGHT_OFFSET);
		}

		// �J�����֘A
		function resetcamera(){s_robot.camera=0;}

		// �c�X�N���[���j�~
		$(document).on('touchmove',function(e){e.preventDefault()});
		// �p���ύX����
		$(window).on('orientationchange',function(e){
			s_canvas.instance.width=window.innerWidth;
			s_canvas.instance.height=window.innerHeight;
			updatetarget(window.innerWidth,window.innerHeight,true);
			resetcamera();
			if(window.orientation==0){
			}else{
			}
		});
		
		// ���[���R���g���[���̈ʒu����
		function getCtrlArea(x, y)
		{
			var width = 225;
			var height = 225;
			
			var _x =    (x - width /2);
			var _y = -1*(y - height/2);
			var v = Math.atan2( _y, _x );
			
			var direction = 0;			
			if( (x - width/2)*(x - width/2)+(y - height/2)*(y - height/2)  < width/2 *height/2 ){
				_x = Math.abs(_x);
				_y = Math.abs(_y);
				if( x<=width/2 && y<=height/2 ) {
					if(_x>_y) {direction = GAME_CONST.MOVE_LEFT;}
					else {direction = GAME_CONST.MOVE_UP;}
				} else if( x>width/2 && y<=height/2 ) {
					if(_x>_y) {direction = GAME_CONST.MOVE_RIGHT;}
					else {direction = GAME_CONST.MOVE_UP;}
				} else if( x<=width/2 && y>height/2 ) {
					if(_x>_y) {direction = GAME_CONST.MOVE_LEFT;}
					else {direction = GAME_CONST.MOVE_DOWN;}
				} else {
					if(_x>_y) {direction = GAME_CONST.MOVE_RIGHT;}
					else {direction = GAME_CONST.MOVE_DOWN;}
				}
			}else{
				//console.log('out circle');
			}
			return direction;
		}
		
		// ���{�b�g�ړ�����
		function checkrange(input,min,max){
			if(input<min){input=min}
			else if(input>max){input=max}
			return input;
		}
		function updaterobotmotion(forward,side,touch){
			side=checkrange(side,0,UI_CONST.MOVE_GRID);
			forward=checkrange(forward,0,UI_CONST.MOVE_GRID);
			s_robot.forward=Math.floor(100*(1-(forward/UI_CONST.MOVE_GRID_HALF)));
			if(touch){
				s_robot.side=Math.floor(-100*(1-(side/UI_CONST.MOVE_GRID_HALF)));
			}else{
				s_robot.side=Math.floor(100*((side/UI_CONST.MOVE_GRID_HALF)-1));
			}
			setflag(PROCESS_FLAGS.MOTION);
		}
		function stoprobotmotion(){
			s_robot.forward=0;
			s_robot.side=0;
			setflag(PROCESS_FLAGS.MOTION);
		}
		
		var s_mousedownflag=false;
		$('#game-movement').on('mousedown touchstart',function(event,ui){	
			var eleoff=$(this).offset();
			var forward=0,side=0,touch=false;
			if(event.type=='mousedown'){
				forward=event.offsetY;
				side=event.offsetX;
			}else{
				forward=event.originalEvent.touches[0].pageY-eleoff.top;
				side=(event.originalEvent.touches[0].pageX-eleoff.left);
				touch=true;
			}
			updaterobotmotion(forward,side,touch);
			s_mousedownflag=true;
			
			var direction = getCtrlArea( event.offsetX, event.offsetY );
			if( direction == 1) meter1.moviePlay();
			if( direction == 2) meter2.moviePlay();
			if( direction == 3) meter3.moviePlay();
			if( direction == 4) meter4.moviePlay();
		});
		$('#game-movement').on('mousemove touchmove',function(event,ui){
			var eleoff=$(this).offset();
			var forward=0,side=0,touch=false;
			if(event.type=='mousemove'){
				if(!event.which)return;
				forward=event.offsetY;
				side=event.offsetX;
			}else{
				forward=event.originalEvent.touches[0].pageY-eleoff.top;
				side=(event.originalEvent.touches[0].pageX-eleoff.left);
				touch=true;
			}
			updaterobotmotion(forward,side,touch);
		});
		$('#game-movement').on('mouseup touchend',function(event,ui){
			stoprobotmotion();
			s_mousedownflag=false;
			meter1.movieReverse();
			meter2.movieReverse();
			meter3.movieReverse();
			meter4.movieReverse();
		});
		$(document).on('mouseup',function(event,ui){
			if(s_mousedownflag){
				stoprobotmotion();
				s_mousedownflag=false;
			}
			if(s_touchgame){
				s_touchgame=false;
			}
		});
		
		var s_touchgame=false;
		$('#game-controls').on('click touchstart',function(event,ui){
			fire();
			s_touchgame=true;
		});
		$('#game-controls').on('mouseup touchmove touchend',function(event,ui){
			playmotion('lowerhands');
		});

		
		// �f�o�b�O����p�l��
		$('#debug_damage').on('click touchstart',function(event,ui){
			
			translateattack();
		});
		$('#debug_win').on('click touchstart',function(event,ui){
		drawResult(UI_CONST.WIN);
		});
		$('#debug_lose').on('click touchstart',function(event,ui){
			drawResult(UI_CONST.LOSE);
		});
		
		var meter1 = $("#move_meter1").movieInit({frames:11, fps:12, direction: "horizontal", repeat: false});
		var meter2 = $("#move_meter2").movieInit({frames:11, fps:12, direction: "horizontal", repeat: false});
		var meter3 = $("#move_meter3").movieInit({frames:11, fps:12, direction: "horizontal", repeat: false});
		var meter4 = $("#move_meter4").movieInit({frames:11, fps:12, direction: "horizontal", repeat: false});
		
		/*$("#button-play-graph").on("click", function(){ g.moviePlay(); });
		$("#button-reverse-graph").on("click", function(){ g.movieReverse(); });
		$("#button-stop-graph").on("click", function(){ g.movieStop(); });
		$("#button-rewind-graph").on("click", function(){ g.movieRewind(); });*/
		
		// �Q�[���֘A
		function ispowerdown(){return (s_robot.mode==ROBOT_MODE.UNACTIVE);}
		function powerdown(){
			s_robot.mode=ROBOT_MODE.UNACTIVE;
			s_robot.lastprocess=PROCESS_FLAGS.CAMERA;
			stoprobotmotion();
		}
		function respawn(){
			systemmessage(UI_CONST.RESET_MSG);
		sendmessage(CMD_TYPE.RESPAWN);
			
			s_robot.power=GAME_CONST.MAX_POWER;
			s_robot.shield=GAME_CONST.MAX_SHIELD;
			s_robot.mode=ROBOT_MODE.ACTIVE;
			playmotion('lowerhands');
			playmotion('standup');
			
			ctx.clearRect(0,0,1136,640);
			drawResult( null );
		}
		function fire(){
			laser();

			var power=s_robot.power-GAME_CONST.ATK_POWER;
			if(power>0){
				sendmessage(CMD_TYPE.ATTACK);
				s_robot.power=power;
				showeffect(SHOW_EFFECT.ATTACK);
				playmotion('attack');
			}else{
				playmotion('lowerhands');
			}
		}
		
		function sendmessage(type){
			var msg={'attack':{'cmd':0,'dat':0}};
			if(type==CMD_TYPE.ATTACK){
				msg['attack']['cmd']=CMD_TYPE.ATTACK;
			}
			else if(type==CMD_TYPE.WIN){
				msg['attack']['cmd']=CMD_TYPE.WIN;
			}
			else if(type==CMD_TYPE.RESPAWN){
				msg['attack']['cmd']=CMD_TYPE.RESPAWN;
			}
			s_r2r.send(msg);
		}
		
		// �����[�g�R�[��
		function remotecallback(msg){
			if(ispowerdown()) return;
			
			var marker=msg['marker'];
			if(marker){
				var x=marker['x'];
				var y=marker['y'];
				updatetarget(x,y);
			}
			var r2rmsg=msg['r2r'];
			if(r2rmsg) {
				var attack=r2rmsg['attack'];
				if(attack){
					var cmdtype=attack['cmd'];
					var cmddat=attack['dat'];
					var markerAttack = attack['marker'];
					
					if(cmdtype==CMD_TYPE.ATTACK && markerAttack){
						if(GAME_CONST.MIN_ATTACKABLE_DISTANCE<=markerAttack['distance']){
							translateattack();
						}
					}else if(cmdtype==CMD_TYPE.WIN){
						drawResult(UI_CONST.WIN);
					}else if(cmdtype==CMD_TYPE.RESPAWN){
						//systemmessage(UI_CONST.RESET_MSG);
						drawResult(null);
					}
				}
			}
		}
		function translateattack(){
			var damage=Math.floor(GAME_CONST.ATK_POWER*(1-s_robot.power/GAME_CONST.MAX_POWER))+GAME_CONST.MIN_ATTACK_DAMAGE;
			s_robot.shield-=damage;
			if(s_robot.shield<0){
				powerdown();
				playmotion('crouch');
				sendmessage(CMD_TYPE.WIN);
				s_robot.shield=0;
				showeffect(SHOW_EFFECT.KNOCKOUT);
				drawResult(UI_CONST.LOSE);
			}else{
				doCrush();
				showeffect(SHOW_EFFECT.DAMAGE);
			}
		}

		
		// �p������֘A
		function bindorientation(){$(window).bind('deviceorientation',oricontrol);}
		function unbindorientation(){$(window).unbind('deviceorientation');}
		function oricontrol(e){
			if(ispowerdown()) return;
			
			var px=e.originalEvent.alpha|0;
			
			if(px>GAME_CONST.MAX_DEVICE_ROT&&px<=180){
				px=GAME_CONST.MAX_DEVICE_ROT;
			}else if(px>180&&px<GAME_CONST.MINUS_CAMERA_ORI){
				px=GAME_CONST.MINUS_CAMERA_ORI;
			}
			px=(Math.sin(px*Math.PI/180)/(GAME_CONST.CAMERA_ROT_DELIMITER));
			s_robot.camera=-Math.floor(GAME_CONST.MAX_CAMERA_ROT*px);
			setflag(PROCESS_FLAGS.CAMERA);
		}
		
		// ���䃋�[�v
		function controlloop(){
			dataupdate();
			if(!s_robot.flags) return;
			
			var cmd=null;
			var lastprocess=s_robot.lastprocess;
			var currprocess=PROCESS_FLAGS.NONE;
			var processed=false;
			if(lastprocess==PROCESS_FLAGS.CAMERA){
				if(isflagup(PROCESS_FLAGS.MOTION)){
					currprocess=PROCESS_FLAGS.MOTION;
				}else if(isflagup(PROCESS_FLAGS.IK)){
					currprocess=PROCESS_FLAGS.IK;
				}else if(isflagup(PROCESS_FLAGS.CAMERA)){
					currprocess=PROCESS_FLAGS.CAMERA;
				}
			}else if(lastprocess==PROCESS_FLAGS.MOTION){
				if(isflagup(PROCESS_FLAGS.IK)){
					currprocess=PROCESS_FLAGS.IK;
				}else if(isflagup(PROCESS_FLAGS.CAMERA)){
					currprocess=PROCESS_FLAGS.CAMERA;
				}else if(isflagup(PROCESS_FLAGS.MOTION)){
					currprocess=PROCESS_FLAGS.MOTION;
				}
			}else if(lastprocess==PROCESS_FLAGS.IK){
				if(isflagup(PROCESS_FLAGS.CAMERA)){
					currprocess=PROCESS_FLAGS.CAMERA;
				}else if(isflagup(PROCESS_FLAGS.MOTION)){
					currprocess=PROCESS_FLAGS.MOTION;
				}else if(isflagup(PROCESS_FLAGS.IK)){
					currprocess=PROCESS_FLAGS.IK;
				}
			}
			
			if(currprocess==PROCESS_FLAGS.CAMERA){
				s_robot.lastprocess=PROCESS_FLAGS.CAMERA;
				offflag(PROCESS_FLAGS.CAMERA);
				
				s_vsido_data.angle['servo'][0]['angle']=s_robot.camera;
				cmd=s_vsido_data.angle;
				
			}else if(currprocess==PROCESS_FLAGS.MOTION){
				s_robot.lastprocess=PROCESS_FLAGS.MOTION
				offflag(PROCESS_FLAGS.MOTION);
				
				s_vsido_data.walk['forward']=s_robot.forward;
				s_vsido_data.walk['turn']=s_robot.side;
				cmd=s_vsido_data.walk;
				
			}else if(currprocess==PROCESS_FLAGS.IK){
				s_robot.lastprocess=PROCESS_FLAGS.IK;
				
				var ikavaiable=0;
				s_vsido_data.ik['kdts']=[];
				for(var key in CUSTOM_MOTION){
					var obj=CUSTOM_MOTION[key];
					if(!obj['inuse']) continue;
					
					var currframe=obj['playframe'];
					var motion=obj['motion'];
					var active=0;
					for(var i=0;i<motion.length;i++){
						var kid=motion[i]['kid'];
						var dat=motion[i]['dat'];
						if(currframe<dat.length){
							var kdt=s_vsido.kdt();
							kdt['kid']=kid;
							kdt['kdt']['pos']['x']=dat[currframe][0];
							kdt['kdt']['pos']['y']=dat[currframe][1];
							kdt['kdt']['pos']['z']=dat[currframe][2];
							s_vsido_data.ik['kdts'].push(kdt);
							active++;
						}
					}
					
					// �A�j���[�V����IK���Ȃ��ꍇ�A�Đ��I���
					if(!active){
						obj['inuse']=false;
					}else{
						obj['playframe']+=1;
						ikavaiable++;
					}
				}
				
				if(ikavaiable){
					cmd=s_vsido_data.ik;
				}else{
					offflag(PROCESS_FLAGS.IK);
				}
			}else{
				// �Ō�̏��������v���Z�X���J�����ɐݒ�
				s_robot.lastprocess=PROCESS_FLAGS.CAMERA;
				resetflag();
			}
			
			if(cmd) s_vsido.send(cmd);
		}
		// �f�o�C�X�̎p������̃o�C���h��L���E������
		var enable_bind_orientation=true;
		function delayexec(){
			if(enable_bind_orientation)bindorientation();
			s_timer[TIMER_TYPE.RENDERER]=setInterval(canvasloop,APP_TIMER.RENDER_LOOP);
			s_timer[TIMER_TYPE.CONTROL]=setInterval(controlloop,APP_TIMER.CONTROL_LOOP);
		}
		function init(){
			if(window.orientation==0){
				s_canvas.instance.width=window.innerWidth;
				s_canvas.instance.height=window.innerHeight;
			}
			resetcamera();
			delayexec();
			
			//s_camera=new VSidoCamera({'ip':s_edison_ip});	// ���J�����摜���ǂ�ip����擾���邩	
			s_camera=new VSidoCamera();
			s_camera.listen(remotecallback);
			s_camera.viewMarkerDetect($('#camera-image'));
			
			//s_r2r=new VSidoR2R({'i':s_edison_ip,'you':s_edison_ip_enemy},remotecallback);	//���ΐ킷�鎩���E�����ip�̎w��
			s_r2r=new VSidoR2R({'you':s_edison_ip_enemy},remotecallback);	// �ΐ푊���ip
			
			
			// �I�t���C���̏ꍇ�̓_�~�[�摜�ɐ؂�ւ���
			if( is_offline ) {
				$("#camera-dummy").css("opacity", 1);
			}
		}
		// ����������
		//load
		//beforeunload 
		$(window)
		.on('pageshow',function(){
			s_canvas.instance.width=window.innerWidth;
			s_canvas.instance.height=window.innerHeight;
			updatetarget(window.innerWidth/2,window.innerHeight/2,true);
			init();
		})
		.on('pagehide',function(){
			if(enable_bind_orientation)unbindorientation();
			clearInterval(s_timer[TIMER_TYPE.CONTROL]);
			clearInterval(s_timer[TIMER_TYPE.RENDERER]);
		})
		.on('resize',function(){
			if(enable_bind_orientation){
				unbindorientation();
				bindorientation();
			}
		})
		;
	
		// -------------�f�o�b�O�֘A-----------------
		function reloadpage(){location.reload(true);}
		$('#debug-reload').on('click',reloadpage);
		function PRINT(txt){$('#debug-print').text(txt);}

		var front_screen = document.getElementById('front_screen');
		var ctx = front_screen.getContext('2d');

		function doCrush()
		{
			var img = new Image();
			type = Math.floor( Math.random() * 2 ) + 1;
			img.src = "./libs/res/crush"+type+".png?" + new Date().getTime();
			/* �摜���ǂݍ��܂��̂�҂��Ă��珈���𑱍s */
			img.onload = function() {

			ratio = (Math.floor( Math.random() * 3)+8)/10;
			x = (Math.floor( Math.random() * 8)-3)*100;
			y = (Math.floor( Math.random() * 4)-2)*100;
			//console.log(x+","+y+","+type+","+ratio);
		    ctx.drawImage(img, 0, 0, img.width, img.height, x, y, img.width*ratio, img.height*ratio);
		    //ctx.drawImage(img, 400, 400);
		  }
		}
		
		function drawResult( result )
		{
			if( result == UI_CONST.WIN )
			{
				//systemmessage(UI_CONST.WIN_MSG);
				$("#result").css('background-image', 'url('+UI_CONST.WIN_IMG+')');
				$("#result").css('visibility', 'visible' );
			}
			else if( result == UI_CONST.LOSE )
			{
				//systemmessage(UI_CONST.LOSE_MSG);
				$("#result").css('background-image', 'url('+UI_CONST.LOSE_IMG+')');
				$("#result").css('visibility', 'visible' );
			}
			else if( result === null || result == UI_CONST.RESET_MSG)
			{
				console.log(result);
				$("#result").css('visibility', 'hidden' );
			}
		}

		function drawGauge( type, value )
		{
			if( type == 'power') {
				max = GAME_CONST.MAX_POWER;
				max_width = UI_CONST.POWER_WIDTH;
			}
			else if( type == 'shield' )
			{
				max = GAME_CONST.MAX_SHIELD;
				max_width = UI_CONST.SHIELD_WIDTH;
			}
			var ratio = (value / max);
			var width = Math.floor(max_width * ratio);
			width = width < 0?0:width;
			//console.log(value+":"+width);
			$('#'+type).css('width', width + 'px');
		}

		var LASER_CONST = {
			WIDTH: 192,
			HEIGHT: 128,
			FPS: 30,
			MAX_FRAME: 9, 
			onceFlg: true,
		};
		var laser_frame = 0;
		var laser_interval = 1/LASER_CONST.FPS*1000;
		var laser_animation;
		
		function laser()
		{
			if( laser_frame != 0 ) return;
	   		
	   		laser_frame = 0;
	   		laser_interval = 1/LASER_CONST.FPS*1000;
	   		clearInterval( laser_animation );
				$("#laser").css("visibility", "visible");
	   		laser_animation = setInterval(intervalEvent, laser_interval);
	   }
		function intervalEvent(){
			$("#laser").css({
				"background-position-x" : -LASER_CONST.WIDTH * laser_frame +"px" // 1�R�}�ÂE�ɂ��炵�Ă���
			});
			laser_frame++;
			if(laser_frame>=LASER_CONST.MAX_FRAME){
				if(LASER_CONST.onceFlg) clearInterval( laser_animation );
				laser_frame = 0;
				$("#laser").css("visibility", "hidden");
			};
		};
		
		if(navigator.userAgent.indexOf('iPhone')  <= -1 && navigator.userAgent.indexOf('iPad')  <= -1) {
			$("#cockpit").css("left", "50%");
			$("#cockpit").css("-webkit-transform", "translate(-50%,0%)");
			$("#cockpit").css("-moz-transform", "translate(-50%,0%)");
			$("#cockpit").css("transform", "translate(-50%,0%)");
		}
	});
	